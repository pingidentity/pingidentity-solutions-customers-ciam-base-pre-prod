ALTER TABLE channel_group ALTER COLUMN saasGroupName varchar(4000);
