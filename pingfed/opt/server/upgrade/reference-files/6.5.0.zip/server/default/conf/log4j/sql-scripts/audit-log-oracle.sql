# ------------------------------------------------------------
# Create table audit_log
# ------------------------------------------------------------

CREATE TABLE audit_log (
  id        INTEGER  PRIMARY KEY,
  dtime     TIMESTAMP,
  event     VARCHAR(255),
  username  VARCHAR(255),
  ip        VARCHAR(255),
  app       VARCHAR(2048),
  host      VARCHAR(255),
  protocol  VARCHAR(255),
  role      VARCHAR(255),
  partnerid VARCHAR(255),
  status    VARCHAR(255),
  adapterid VARCHAR(255),
  description VARCHAR(2048)
);

CREATE SEQUENCE audit_log_sequence
START WITH 1
INCREMENT BY 1;

CREATE OR REPLACE TRIGGER audit_log_trigger BEFORE INSERT ON audit_log REFERENCING NEW AS NEW FOR EACH ROW BEGIN SELECT audit_log_sequence.nextval INTO :NEW.ID FROM dual; END;
.
RUN
 
